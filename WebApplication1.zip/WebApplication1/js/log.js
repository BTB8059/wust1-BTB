//$(function(){
//	$(".form-control").blur(function(){
//			var regex = new RegExp($(this).attr('regex'));
//			//console.log($(this).val());
//			if(!regex.test($(this).val())){
//				$(this).addClass('error');
//			}else{
//				$(this).addClass('focus');
//			}
//	})
//})
